package com.example.smdass3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class startPage extends AppCompatActivity {

    EditText etusername,etpassword,etURL;

    Button btnsubmit,btnupdate,btnlist,btndelete;
    DBHelper DB;
    final int THIRD_ACTIVITY = 3;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_page);
        etusername = findViewById(R.id.etusername);
        etpassword = findViewById(R.id.etpassword);
        etURL = findViewById(R.id.eturl);
        btnsubmit = findViewById(R.id.btnsubmit);
        btnupdate = findViewById(R.id.btnupdate);
        btnlist = findViewById(R.id.btnlist);
        btndelete = findViewById(R.id.btndelete);
        DB = new DBHelper(this);
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username, password, URL;
                username = etusername.getText().toString().trim();
                password = etpassword.getText().toString().trim();
                URL = etURL.getText().toString().trim();
                if (username.equals("") || password.equals("") || URL.equals("")) {
                    Toast.makeText(startPage.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean insert = DB.insertPassword(username,password,URL);
                    //DB.deleteAllPasswords();
                    if(insert==true)
                        Toast.makeText(startPage.this, "Password Added Successfully", Toast.LENGTH_SHORT).show();
                }


            }
        });
        btnlist.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pass = DB.printPass();

                Intent intent = new Intent(startPage.this,PassList.class);
                intent.putExtra("passwords",pass);
                startActivity(intent);
                finish();
            }
        });
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(startPage.this,UpdatePassword.class);
                startActivity(intent);
                finish();
            }
        });
        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(startPage.this,DeletePage.class);
                startActivity(intent);
                finish();
            }
        });
    }


}