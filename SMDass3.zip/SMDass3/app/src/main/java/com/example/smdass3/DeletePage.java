package com.example.smdass3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class DeletePage extends AppCompatActivity {
    EditText etusername,etpassword,etURL;
    Button btnsubmit,btnbin;
    TextView tvpassdeleted;
    DBHelper DB;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_page);
        etusername = findViewById(R.id.etusername);
        etpassword = findViewById(R.id.etpassword);
        etURL = findViewById(R.id.eturl);
        tvpassdeleted = findViewById(R.id.tvpassdeleted);
        btnsubmit = findViewById(R.id.btnsubmit);
        btnbin = findViewById(R.id.btnbin);
        DB = new DBHelper(this);


        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username,password,URL;
                username = etusername.getText().toString().trim();
                password = etpassword.getText().toString().trim();
                URL = etURL.getText().toString().trim();
                Boolean get = DB.insertDeleted(username,password,URL);
                boolean result = DB.deletePassword(username,password,URL);
                if(result)
                    Toast.makeText(DeletePage.this, "Password Deleted Successfully", Toast.LENGTH_SHORT).show();
            }
        });
        btnbin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass = DB.printPassDeleted();
                tvpassdeleted.setText(pass);
                Intent intent = new Intent(DeletePage.this,RecycleBin.class);
                intent.putExtra("passwordDeleted",pass);
                startActivity(intent);
                finish();
            }
        });
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(DeletePage.this, startPage.class);
        startActivity(intent);
        finish(); // Optional, if you want to finish the current activity
    }
}