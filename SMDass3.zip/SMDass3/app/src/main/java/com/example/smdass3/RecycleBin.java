package com.example.smdass3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class RecycleBin extends AppCompatActivity {
    TextView tvdeleted;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_bin);
        tvdeleted = findViewById(R.id.tvdeleted);
        Intent i = getIntent();
        String passwords = i.getStringExtra("passwordDeleted");
        tvdeleted.setText(passwords);
  }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(RecycleBin.this, startPage.class);
        startActivity(intent);
        finish();
   }
}