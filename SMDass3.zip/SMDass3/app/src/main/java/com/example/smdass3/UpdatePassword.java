package com.example.smdass3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdatePassword extends AppCompatActivity {
    EditText etpassword, etURL, etoldusername;
    Button btnsubmit, btnpasswords; // Initialize buttons
    DBHelper DB;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);

        etoldusername = findViewById(R.id.etoldusername);
        etpassword = findViewById(R.id.etpassword);
        etURL = findViewById(R.id.eturl);
        btnsubmit = findViewById(R.id.btnupdate);
        btnpasswords = findViewById(R.id.btnlist);
        DB = new DBHelper(this);
        btnsubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username, password, URL;
                username = etoldusername.getText().toString().trim();
                password = etpassword.getText().toString().trim();
                URL = etURL.getText().toString().trim();
                if (username.equals("") || password.equals("") || URL.equals("")) {
                    Toast.makeText(UpdatePassword.this, "Please enter all the fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean update = DB.updatePassword(username,password,URL);
                    if(update==true)
                        Toast.makeText(UpdatePassword.this, "Password Added Successfully", Toast.LENGTH_SHORT).show();
                }


            }
        });

        btnpasswords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass = DB.printPass();
                //tvlist.setText(pass);
                Intent intent = new Intent(UpdatePassword.this, PassList.class);
                intent.putExtra("passwords", pass);
                startActivity(intent);
                finish();
            }
        });
    }
}
