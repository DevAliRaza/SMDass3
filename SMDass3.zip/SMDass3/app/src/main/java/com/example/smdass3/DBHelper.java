package com.example.smdass3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "Login.db";

    public DBHelper(Context context) {
        super(context, "Login.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(User_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT, password TEXT)");
        MyDB.execSQL("create Table Passwords(_ID INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT,password TEXT,URL TEXT )");
        MyDB.execSQL("create Table Deleted(_ID INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT,password TEXT,URL TEXT) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
        MyDB.execSQL("drop Table if exists Passwords");
        MyDB.execSQL("drop Table if exists Deleted");
    }

    public Boolean insertData(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDB.insert("users", null, contentValues);
        if(result==-1) return false;
        else
            return true;
    }
    public Boolean insertPassword(String username,String password,String URL){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues cv= new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        cv.put("URL",URL);
        long result = MyDB.insert("Passwords", null, cv);
        if(result==-1) return false;
        else
            return true;
    }
    public Boolean insertDeleted(String username,String password,String URL){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues cv= new ContentValues();
        cv.put("username", username);
        cv.put("password", password);
        cv.put("URL",URL);
        long result = MyDB.insert("Deleted", null, cv);
        if(result==-1) return false;
        else
            return true;
    }
    public String printPass() {
        SQLiteDatabase MyDB = this.getReadableDatabase();
        String[] columns = {"username", "password", "URL"};
        Cursor cursor = MyDB.query("Passwords", columns, null, null, null, null, null);

        int usernameIndex = cursor.getColumnIndex("username");
        int passwordIndex = cursor.getColumnIndex("password");
        int URLIndex = cursor.getColumnIndex("URL");

        StringBuilder passwordsString = new StringBuilder();

        if (cursor.moveToFirst()) {
            do {
                if (usernameIndex != -1 && passwordIndex != -1 && URLIndex != -1) {
                    String username = cursor.getString(usernameIndex);
                    String password = cursor.getString(passwordIndex);
                    String URL = cursor.getString(URLIndex);

                    // Append the retrieved information to the string
                    passwordsString.append("Username: ").append(username).append(", Password: ").append(password).append(", URL: ").append(URL).append("\n");
                }
            } while (cursor.moveToNext());
        }

        cursor.close();

        // Return the string containing all passwords
        return passwordsString.toString();
    }
    public String printPassDeleted() {
        SQLiteDatabase MyDB = this.getReadableDatabase();
        String[] columns = {"username", "password", "URL"};
        Cursor cursor = MyDB.query("Deleted", columns, null, null, null, null, null);

        StringBuilder deletedEntriesString = new StringBuilder();

        int usernameIndex = cursor.getColumnIndex("username");
        int passwordIndex = cursor.getColumnIndex("password");
        int URLIndex = cursor.getColumnIndex("URL");

        if (cursor.moveToFirst()) {
            do {
                if (usernameIndex != -1 && passwordIndex != -1 && URLIndex != -1) {
                    String username = cursor.getString(usernameIndex);
                    String password = cursor.getString(passwordIndex);
                    String URL = cursor.getString(URLIndex);

                    // Append the retrieved information to the string
                    deletedEntriesString.append("Username: ").append(username).append(", Password: ").append(password).append(", URL: ").append(URL).append("\n");
                }
            } while (cursor.moveToNext());
        }

        cursor.close();

        // Return the string containing all deleted entries
        return deletedEntriesString.toString();
    }


    public boolean updatePassword(String oldusername,String password,String URL){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("password", password);
        cv.put("URL", URL);

        // Specify which row to update based on the old username
        int rowsAffected = MyDB.update("Passwords", cv, "username=?", new String[]{oldusername});

        // Check if the update was successful
        if (rowsAffected > 0) {
            return true; // Update successful
        } else {
            return false; // Update failed
        }
    }

    public Boolean checkusername(String username) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }
    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean deletePassword(String username,String password,String URL) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        int rowsDeleted = MyDB.delete("Passwords", "username=?", new String[]{username});
        MyDB.close();

        return rowsDeleted > 0;
    }

}