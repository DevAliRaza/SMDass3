package com.example.smdass3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class PassList extends AppCompatActivity {
    TextView tvpasswords;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pass_list);
        tvpasswords = findViewById(R.id.tvpasswords);
        Intent i = getIntent();
        String passwords = i.getStringExtra("passwords");
        tvpasswords.setText(passwords);
    }
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(PassList.this, startPage.class);
        startActivity(intent);
        finish(); // Optional, if you want to finish the current activity
    }

}